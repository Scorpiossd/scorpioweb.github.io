<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header("Location: index.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['message'])) {
    $message = htmlspecialchars($_POST['message']);
    $user = $_SESSION['username'];
    $line = "$user: $message\n";
    file_put_contents("messages.txt", $line, FILE_APPEND);

    $reply = '';
    $lowerMsg = strtolower($message);
    if ($lowerMsg === 'halo') {
        $reply = "ScorpioBot: Halo juga, $user! Ada yang bisa aku bantu?\n";
    } elseif ($lowerMsg === 'siapa kamu?') {
        $reply = "ScorpioBot: Aku bot buatan Scorpio Team 😎\n";
    } elseif (strpos($lowerMsg, 'help') !== false) {
        $reply = "ScorpioBot: Ketik 'menu' untuk melihat fitur!\n";
    } elseif ($lowerMsg === 'menu') {
        $reply = "ScorpioBot: Pilihan:\n- halo\n- siapa kamu?\n- help\n";
    }

    if ($reply !== '') {
        sleep(1);
        file_put_contents("messages.txt", $reply, FILE_APPEND);
    }

    header("Location: home.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Scorpio Chat Room</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="bg">
    <div class="container">
        <h1 class="title">🦂 Scorpio Chat Room</h1>
        <div class="chat-box">
            <?php
            if (file_exists("messages.txt")) {
                $lines = file("messages.txt", FILE_IGNORE_NEW_LINES);
                foreach ($lines as $line) {
                    echo "<p>" . htmlspecialchars($line) . "</p>";
                }
            } else {
                echo "<p>Belum ada pesan.</p>";
            }
            ?>
        </div>
        <form method="post" class="input-form">
            <input type="text" name="message" placeholder="Ketik pesan..." required>
            <button type="submit">Kirim</button>
        </form>
        <br>
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>
</body>
</html>
