<?php
session_start();

$users = [
    "H20" => "Matcha",
    "admin" => "12345",
    "nabil" => "rahasia"
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if (isset($users[$username]) && $users[$username] === $password) {
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = $username;
        header("Location: home.php");
        exit;
    } else {
        $error = "Username atau password salah!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login Scorpio</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="bg-login">
    <div class="login-container">
        <h2 class="big-s">🦂 Scorpio</h2>
        <h3>Login ke Scorpio Web</h3>
        <?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
        <form method="post">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Login</button>
        </form>
    </div>
</body>
</html>
